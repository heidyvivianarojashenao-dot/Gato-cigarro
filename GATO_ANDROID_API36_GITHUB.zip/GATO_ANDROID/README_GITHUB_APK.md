# GATO — APK gratis por GitHub Actions

Este proyecto empaqueta la versión web de GATO V43 dentro de una app Android independiente.
- compileSdk/targetSdk: 36 (Android 16)
- applicationId: com.gato.app
- versionName: 43.0
- No depende de Netlify para funcionar una vez instalada.

## GitHub Actions
Sube este proyecto descomprimido al repositorio y crea `.github/workflows/android.yml` con el workflow de construcción. También puedes subir este ZIP y usar un workflow que lo descomprima, igual que en Botanas.
