package com.gato.app;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WebView webView;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(25, 56, 47));
        getWindow().setNavigationBarColor(Color.rgb(25, 56, 47));

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(25, 56, 47));
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setSupportZoom(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        webView.addJavascriptInterface(new AndroidBridge(), "GatoAndroid");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return openExternalIfNeeded(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalIfNeeded(Uri.parse(url));
            }
        });

        webView.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                startActivity(i);
            } catch (Exception e) {
                Toast.makeText(this, "No se pudo abrir el archivo.", Toast.LENGTH_SHORT).show();
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private class AndroidBridge {
        @JavascriptInterface
        public boolean saveImage(String base64, String fileName) {
            try {
                byte[] bytes = decode(base64);
                String safeName = safeFileName(fileName);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    ContentValues values = new ContentValues();
                    values.put(MediaStore.Images.Media.DISPLAY_NAME, safeName);
                    values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                    values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GATO");
                    values.put(MediaStore.Images.Media.IS_PENDING, 1);
                    Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                    if (uri == null) return false;
                    try (OutputStream out = getContentResolver().openOutputStream(uri)) {
                        if (out == null) throw new Exception("No se pudo abrir el destino");
                        out.write(bytes);
                    }
                    ContentValues done = new ContentValues();
                    done.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(uri, done, null, null);
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket guardado en Galería > GATO", Toast.LENGTH_SHORT).show());
                    return true;
                } else {
                    File dir = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "GATO");
                    if (!dir.exists() && !dir.mkdirs()) return false;
                    File file = new File(dir, safeName);
                    try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }
                    runOnUiThread(() -> Toast.makeText(MainActivity.this, "Ticket guardado.", Toast.LENGTH_SHORT).show());
                    return true;
                }
            } catch (Exception e) {
                return false;
            }
        }

        @JavascriptInterface
        public boolean shareImage(String base64, String fileName, String title, String text) {
            try {
                byte[] bytes = decode(base64);
                String safeName = safeFileName(fileName);
                File dir = new File(getCacheDir(), "shared_images");
                if (!dir.exists() && !dir.mkdirs()) return false;
                File file = new File(dir, safeName);
                try (FileOutputStream out = new FileOutputStream(file)) { out.write(bytes); }

                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent send = new Intent(Intent.ACTION_SEND);
                send.setType("image/png");
                send.putExtra(Intent.EXTRA_STREAM, uri);
                send.putExtra(Intent.EXTRA_TEXT, text == null ? "" : text);
                send.putExtra(Intent.EXTRA_TITLE, title == null ? "GATO" : title);
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                // Enviar como se hace normalmente desde Android: abrir WhatsApp
                // directamente con la imagen y el mensaje ya preparados.
                try {
                    send.setPackage("com.whatsapp");
                    startActivity(send);
                    return true;
                } catch (ActivityNotFoundException ignored) {
                    // Si WhatsApp no está instalado, mostramos el selector normal.
                    send.setPackage(null);
                    Intent chooser = Intent.createChooser(send, "Enviar ticket GATO");
                    startActivity(chooser);
                    return true;
                }
            } catch (ActivityNotFoundException e) {
                return false;
            } catch (Exception e) {
                return false;
            }
        }

        private byte[] decode(String value) {
            String v = value == null ? "" : value;
            int comma = v.indexOf(',');
            if (comma >= 0) v = v.substring(comma + 1);
            return Base64.decode(v, Base64.DEFAULT);
        }

        private String safeFileName(String name) {
            String n = name == null ? "Ticket-GATO.png" : name.replaceAll("[^A-Za-z0-9._-]", "_");
            if (!n.toLowerCase().endsWith(".png")) n += ".png";
            return n;
        }
    }

    private boolean openExternalIfNeeded(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme == null) return false;
        if (scheme.equals("file") || scheme.equals("about") || scheme.equals("data") || scheme.equals("blob")) return false;
        if (scheme.equals("http") || scheme.equals("https") || scheme.equals("whatsapp") || scheme.equals("mailto") || scheme.equals("tel")) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); } catch (ActivityNotFoundException ignored) {}
            return true;
        }
        return false;
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.loadUrl("about:blank"); webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
